@extends('layouts.principal')
@section('title', 'Cargar Reprote')
@section('subtitle', 'CARGAR REPORTE')
@section('content')
	{{Form::open(['route' => 'reportes.store', 'method' => 'POST', 'id' => 'form-crear-reporte'])}}
		<div class="row">
			<div class="col-md-4">
				<div class="form-group {{ $errors->has('ruta') ? ' has-error ' : ''}}">
					<label for="ruta">Archivo</label>
					<input type="file" name="ruta" id="ruta">
					@if ($errors->has('ruta'))
			            <span>
			              <strong>{{ $errors->first('ruta') }}</strong>
			            </span>
		        	@endif
				</div>
			</div>
			<div class="col-md-4">
				<div class="form-group {{ $errors->has('nombre_archivo') ? ' has-error ' : ''}}">
					<label for="nombre_archivo">Nombre Reporte</label>
					<input type="text" id="nombre_archivo" name="nombre_archivo" class="form-control" value="{{old('nombre_archivo')}}" required placeholder="Nombre reporte" autofocus>
					@if ($errors->has('nombre_archivo'))
            <span>
              <strong>{{ $errors->first('nombre_archivo') }}</strong>
            </span>
        	@endif
				</div>
			</div>
			<div class="col-md-4">
				<div class="form-group {{ $errors->has('estado') ? ' has-error ' : ''}}">
					<label for="estado">Estado</label>
					<select id="estado name="estado" class="form-control">
						<option value="0">Seleccionar</option>
						<option value="1">Publicado</option>
						<option value="2">No publicado</option>
					</select>
					@if ($errors->has('estado'))
			            <span>
			              <strong>{{ $errors->first('estado') }}</strong>
			            </span>
		        	@endif
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-md-12">
				<button type="submit" class="btn btn-primary"><i class="fa fa-floppy-o" aria-hidden="true"></i> Guardar</button>
			</div>
		</div>
	{{Form::close()}}
@endsection

<div class="row">
	<div class="col-md-12 msjNoRegis">
		<h3>Sin registros para mostrar</h3>
	</div>
</div>
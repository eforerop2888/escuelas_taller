<div class="row">
	<div class="col-md-12 msjNoRegis">
		<h3>Primero deben de existir escuelas creadas en tu país</h3>
	</div>
</div>
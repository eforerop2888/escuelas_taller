<?php $__env->startSection('title', 'Detalle Programa'); ?>
<?php $__env->startSection('content'); ?>
	<div class="panel panel-primary">
		<div class="panel-heading">
			Detalle programa <?php echo e($programa->nombre); ?>

		</div>
		<div class="panel-body">
			<?php if( $programa->count()): ?>
				<div class="table-responsive">
					<table class="table table-hover">
						<tr>
							<th>Duración (Meses)</th>
							<td><?php echo e($programa->duracion_meses); ?></td>
						</tr>
						<tr>
							<th>Duración en total (Horas)</th>
							<td><?php echo e($programa->duracion_horas); ?></td>
						<tr/>
						<tr>
							<th>Duración practica (Horas)</th>
							<td><?php echo e($programa->duracion_practicas_horas); ?></td>
						<tr/>
						<tr>
							<th>Objetivo del Programa</th>
							<td><?php echo e($programa->objetivo_programa); ?></td>
						<tr/>
						<tr>
							<th>Requisitos de ingreso</th>
							<td><?php echo e($programa->requisitos_ingreso); ?></td>
						<tr/>
						<tr>
							<th>Perfil de espacios laborales</th>
							<td><?php echo e($programa->trabajo_egresados); ?></td>
						<tr/>
						<tr>
							<th>Escuela</th>
							<td><?php echo e($programa->nombre_escuela); ?></td>
						<tr/>
						<tr>
							<th>País</th>
							<td><?php echo e(ucfirst($programa->pais)); ?></td>
						<tr/>
						<tr>
							<th>Estado</th>
							<td><?php echo e(ucfirst($programa->estado)); ?></td>
						<tr/>
					</table>
				</div>
			<?php endif; ?>
			<?php if(Auth::user()->pais_id == $programa->pais_id): ?>
				<div class="row">
					<div class="col-md-6">
						<?php echo e(Form::open(['method' => 'Get', 'route' => ['programas.edit', $programa->id]])); ?>

							<button type="submit" class="btn btn-warning">
								<i class="fa fa-edit" aria-hidden="true"></i>
								Editar Programa
							</button>
						<?php echo e(Form::close()); ?>

					</div>
					<?php if(Auth::user()->role_id == 1): ?>
						<div class="col-md-6">
							<?php echo e(Form::open(['method' => 'Delete', 'route' => ['programas.destroy', $programa->id], 'class' => 'form-eliminar'])); ?>

								<button type="submit" class="btn btn-danger">
									<i class="fa fa-eraser" aria-hidden="true"></i>
									Eliminar Programa
								</button>
							<?php echo e(Form::close()); ?>

						</div>
					<?php endif; ?>
				</div>
			<?php endif; ?>
		</div>
	</div>
	<div class="panel panel-warning">
		<div class="panel-heading">
			Estudiantes
		</div>
		<div class="panel-body">
		<?php if( !empty($estudiantes)): ?>
			<div class="table-responsive">
				<table class="table table-hover">
					<tr>
						<th></th>
						<th>Mujeres</th>
						<th>Hombres</th>
					</tr>
					<tr>
						<th>Estudiantes Matriculados</th>
						<td><?php echo e($estudiantes->total_mujeres); ?></td>
						<td><?php echo e($estudiantes->total_hombres); ?></td>
					</tr>
					<tr>
						<th>Blancos</th>
						<td><?php echo e($estudiantes->blanco_mujeres); ?></td>
						<td><?php echo e($estudiantes->blanco_hombres); ?></td>
					</tr>
					<tr>
						<th>Caucásicos</th>
						<td><?php echo e($estudiantes->caucasico_mujeres); ?></td>
						<td><?php echo e($estudiantes->caucasico_hombres); ?></td>
					</tr>
					<tr>
						<th>Afrodescendientes</th>
						<td><?php echo e($estudiantes->afrodescendiente_mujeres); ?></td>
						<td><?php echo e($estudiantes->afrodescendiente_hombres); ?></td>
					</tr>
					<tr>
						<th>Indígenas</th>
						<td><?php echo e($estudiantes->indigena_mujeres); ?></td>
						<td><?php echo e($estudiantes->indigena_hombres); ?></td>
					</tr>
					<tr>
						<th>Mestizos</th>
						<td><?php echo e($estudiantes->mestizo_mujeres); ?></td>
						<td><?php echo e($estudiantes->mestizo_hombres); ?></td>
					</tr>
					<tr>
						<th>Raizal (isleño)</th>
						<td><?php echo e($estudiantes->raizal_isleno_mujeres); ?></td>
						<td><?php echo e($estudiantes->raizal_isleno_hombres); ?></td>
					</tr>
					<tr>
						<th>Rom (Gitano)</th>
						<td><?php echo e($estudiantes->rom_gitano_mujeres); ?></td>
						<td><?php echo e($estudiantes->rom_gitano_hombres); ?></td>
					</tr>
					<tr>
						<th>Criollo</th>
						<td><?php echo e($estudiantes->criollo_mujeres); ?></td>
						<td><?php echo e($estudiantes->criollo_hombres); ?></td>
					</tr>
					<tr>
						<th>Amerindio</th>
						<td><?php echo e($estudiantes->amerindio_mujeres); ?></td>
						<td><?php echo e($estudiantes->amerindio_hombres); ?></td>
					</tr>
					<tr>
						<th>Polinesio</th>
						<td><?php echo e($estudiantes->polinesio_mujeres); ?></td>
						<td><?php echo e($estudiantes->polinesio_hombres); ?></td>
					</tr>
					<tr>
						<th>Melanesio</th>
						<td><?php echo e($estudiantes->melanesio_mujeres); ?></td>
						<td><?php echo e($estudiantes->melanesio_hombres); ?></td>
					</tr>
					<tr>
						<th>Asiático</th>
						<td><?php echo e($estudiantes->asiatico_mujeres); ?></td>
						<td><?php echo e($estudiantes->asiatico_hombres); ?></td>
					</tr>
					<tr>
						<th>Victimas</th>
						<td><?php echo e($estudiantes->victimas_mujeres); ?></td>
						<td><?php echo e($estudiantes->victimas_hombres); ?></td>
					<tr/>
					<tr>
						<th>Excombatientes</th>
						<td><?php echo e($estudiantes->excombatientes_mujeres); ?></td>
						<td><?php echo e($estudiantes->excombatientes_hombres); ?></td>
					<tr/>
					<tr>
						<th>Desplazados</th>
						<td><?php echo e($estudiantes->desplazados_mujeres); ?></td>
						<td><?php echo e($estudiantes->desplazados_hombres); ?></td>
					<tr/>
					<tr>
						<th>Pobreza</th>
						<td><?php echo e($estudiantes->pobreza_mujeres); ?></td>
						<td><?php echo e($estudiantes->pobreza_hombres); ?></td>
					<tr/>
					<tr>
						<th>Cabeza de familia</th>
						<td><?php echo e($estudiantes->cabeza_mujeres); ?></td>
						<td><?php echo e($estudiantes->cabeza_hombres); ?></td>
					<tr/>
					<tr>
						<th>Estudiantes Certificados</th>
						<td><?php echo e($estudiantes->certificados_mujeres); ?></td>
						<td><?php echo e($estudiantes->certificados_hombres); ?></td>
					<tr/>
					<tr>
						<th>Egresados Programa</th>
						<td><?php echo e($estudiantes->egresados_programa_mujeres); ?></td>
						<td><?php echo e($estudiantes->egresados_programa_hombres); ?></td>
					<tr/>
					<tr>
						<th>Estudiantes con trabajo</th>
						<td><?php echo e($estudiantes->egresados_trabajo_mujeres); ?></td>
						<td><?php echo e($estudiantes->egresados_trabajo_hombres); ?></td>
					<tr/>
					<tr>
						<th>Estudiantes con trabajo en otro oficio</th>
						<td><?php echo e($estudiantes->egresados_trabajo_otro_mujeres); ?></td>
						<td><?php echo e($estudiantes->egresados_trabajo_otro_hombres); ?></td>
					<tr/>
					<tr>
						<th>Estudiantes con trabajo en otro oficio</th>
						<td><?php echo e($estudiantes->egresados_desempleados_mujeres); ?></td>
						<td><?php echo e($estudiantes->egresados_desempleados_hombres); ?></td>
					<tr/>
					<tr>
						<th>Causas Deserción</th>
						<td colspan="2"><?php echo e($estudiantes->causas_desercion); ?></td>
					</tr>
					<tr>
						<th>Observaciones</th>
						<td colspan="2"><?php echo e($estudiantes->observaciones); ?></td>
					</tr>
				</table>
			</div>
		<?php endif; ?>
		<?php if(Auth::user()->pais_id == $programa->pais_id): ?>
			<div class="row">
				<div class="col-md-6">
				<?php echo e(Form::open(['method' => 'Get', 'route' => ['estudiantes.create']])); ?>

					<input type="hidden" name="programa_id" id="programa_id" value="<?php echo e($programa->id); ?>">
					<button type="submit" class="btn btn-warning">
						<i class="fa fa-edit" aria-hidden="true"></i>
						Editar Estudiantes
					</button>
				<?php echo e(Form::close()); ?>

				</div>
				<?php if( !empty($estudiantes) && Auth::user()->role_id == 1 ): ?>
					<div class="col-md-6">
						<?php echo e(Form::open(['method' => 'Delete', 'route' => ['estudiantes.destroy', $programa->id], 'class' => 'form-eliminar'])); ?>

							<button type="submit" class="btn btn-danger">
								<i class="fa fa-eraser" aria-hidden="true"></i> Eliminar información estudiantes
							</button>
						<?php echo e(Form::close()); ?>

					</div>
				<?php endif; ?>
			</div>
		<?php endif; ?>	
		</div>
	</div>
	<div class="panel panel-success">
		<div class="panel-heading">
			Módulos | Materias
		</div>
		<div class="panel-body">
			<?php if( $modulos->count()): ?>
				<div class="table-responsive">
					<table class="table table-hover">
						<tr>
							<th>Nombre Módulo</th>
							<th>Duración Meses</th>
							<th>Tipo</th>
							<th>Nombre Maestro</th>
							<?php if(Auth::user()->pais_id == $programa->pais_id): ?>
								<th>Ver</th>
								<th>Eliminar</th>
							<?php endif; ?>
						</tr>
						<?php $__currentLoopData = $modulos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rowmodulos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr>
								<td><?php echo e(ucfirst($rowmodulos->nombre)); ?></td>
								<td><?php echo e($rowmodulos->duracion); ?></td>
								<td><?php echo e(ucfirst($rowmodulos->tipo)); ?></td>
								<td><?php echo e(ucfirst($rowmodulos->nombre_maestro)); ?></td>
								<?php if(Auth::user()->pais_id == $programa->pais_id): ?>
									<td>
										<?php echo e(Form::open(['method' => 'Get', 'route' => ['modulos.show', $rowmodulos->id_modulos]])); ?>

											<button type="submit" class="btn btn-success">
												<i class="fa fa-eye" aria-hidden="true"></i>
											</button>
										<?php echo e(Form::close()); ?>

									</td>
									<td>
										<?php echo e(Form::open(['method' => 'Delete', 'route' => ['modulos.destroy', $rowmodulos->id_modulos]])); ?>

											<input type="hidden" name="id_programam" value="<?php echo e($programa->id); ?>">
											<button type="submit" class="btn btn-danger">
												<i class="fa fa-eraser" aria-hidden="true"></i>
											</button>
										<?php echo e(Form::close()); ?>

									</td>
								<?php endif; ?>
							</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</table>
				</div>
			<?php endif; ?>
			<?php if(Auth::user()->pais_id == $programa->pais_id): ?>
				<div class="row">
					<div class="col-md-6">
						<?php echo e(Form::open(['method' => 'Get', 'route' => ['modulos.create']])); ?>

							<input type="hidden" name="programa_id_m" id="programa_id_m" value="<?php echo e($programa->id); ?>">
							<button type="submit" class="btn btn-primary">
								<i class="fa fa-pencil" aria-hidden="true"></i> Crear Modulo | Matería
							</button>
						<?php echo e(Form::close()); ?>

					</div>			
				</div>
			<?php endif; ?>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.secundario', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
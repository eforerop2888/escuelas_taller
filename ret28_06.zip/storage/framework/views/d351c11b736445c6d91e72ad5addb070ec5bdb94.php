<?php $__env->startSection('title', 'Crear Escuela'); ?>
<?php $__env->startSection('subtitle', 'ESCUELAS - CREAR'); ?>
<?php $__env->startSection('content'); ?>
	<?php echo e(Form::open(['route' => 'escuelas.store', 'method' => 'POST', 'id' => 'form-crear-escuela'])); ?>

		<div class="row">
			<div class="col-md-6">
				<div class="form-group <?php echo e($errors->has('nombre_escuela') ? ' has-error ' : ''); ?>">
					<label for="nombre_escuela">Nombre Escuela</label>
					<input type="text" id="nombre_escuela" name="nombre_escuela" class="form-control" required value="<?php echo e(old('nombre_escuela')); ?>" placeholder="Nombre Escuela" autofocus>
					<?php if($errors->has('nombre_escuela')): ?>
	          <span>
	            <strong><?php echo e($errors->first('nombre_escuela')); ?></strong>
	          </span>
	      	<?php endif; ?>
				</div>
			</div>
			<div class="col-md-6">
				<div class="form-group <?php echo e($errors->has('pagina_web') ? ' has-error ' : ''); ?>">
					<label for="pagina_web">Página web</label>
					<input type="text" id="pagina_web" name="pagina_web" class="form-control" value="<?php echo e(old('pagina_web')); ?>" placeholder="Página Web">
					<?php if($errors->has('pagina_web')): ?>
	          <span>
	            <strong><?php echo e($errors->first('pagina_web')); ?></strong>
	          </span>
	      	<?php endif; ?>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-md-6">
				<div class="form-group <?php echo e($errors->has('direccion') ? ' has-error ' : ''); ?>">
					<label for="direccion">Dirección</label>
					<input type="text" id="direccion" name="direccion" class="form-control" required value="<?php echo e(old('direccion')); ?>" placeholder="Dirección">
					<?php if($errors->has('direccion')): ?>
	          <span>
	            <strong><?php echo e($errors->first('direccion')); ?></strong>
	          </span>
	      	<?php endif; ?>
				</div>
			</div>
			<div class="col-md-6">
				<div class="form-group <?php echo e($errors->has('telefono') ? ' has-error ' : ''); ?>">
					<label for="telefono">Teléfono
					<a href="#" class="tooltips" title="Ingresa el número con prefijo de tu país y código de área. Ej: +571 3283787">
							<i class="fa fa-question-circle" aria-hidden="true"></i>
						</a>
					</label>
					<input type="text" id="telefono" name="telefono" class="form-control" required value="<?php echo e(old('telefono')); ?>" placeholder="Teléfono">
					<?php if($errors->has('telefono')): ?>
	          <span>
	            <strong><?php echo e($errors->first('telefono')); ?></strong>
	          </span>
	      	<?php endif; ?>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-md-6">
				<div class="form-group <?php echo e($errors->has('director') ? ' has-error ' : ''); ?>">
					<label for="director">
						Director | Coordinador General
					</label>
					<input type="text" id="director" name="director" class="form-control" required value="<?php echo e(old('director')); ?>" placeholder="Director | Coordinador">
					<?php if($errors->has('director')): ?>
	          <span>
	            <strong><?php echo e($errors->first('director')); ?></strong>
	          </span>
	      	<?php endif; ?>
				</div>
			</div>
			<div class="col-md-6">
				<div class="form-group <?php echo e($errors->has('email') ? ' has-error ' : ''); ?>">
					<label for="email">
						Email Director | Coordinador General
					</label>
					<input type="email" id="email" name="email" class="form-control" required value="<?php echo e(old('email')); ?>" placeholder="Email Director | Coordinador">
					<?php if($errors->has('email')): ?>
	          <span>
	            <strong><?php echo e($errors->first('email')); ?></strong>
	          </span>
	      	<?php endif; ?>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-md-6">
				<div class="form-group <?php echo e($errors->has('coordinador') ? ' has-error ' : ''); ?>">
					<label for="coordinador">Coordinador Academico</label>
					<input type="text" id="coordinador" name="coordinador" class="form-control" required value="<?php echo e(old('coordinador')); ?>" placeholder="Coordinador Academico">
					<?php if($errors->has('coordinador')): ?>
	          <span>
	            <strong><?php echo e($errors->first('coordinador')); ?></strong>
	          </span>
	      	<?php endif; ?>
				</div>
			</div>
			<div class="col-md-6">
				<div class="form-group <?php echo e($errors->has('email_c') ? ' has-error ' : ''); ?>">
					<label for="email_c">Email Coordinador Academico</label>
					<input type="email" id="email_c" name="email_c" class="form-control" required value="<?php echo e(old('email_c')); ?>" placeholder="Email Coordinador Academico">
					<?php if($errors->has('email_c')): ?>
	          <span>
	            <strong><?php echo e($errors->first('email_c')); ?></strong>
	          </span>
	      	<?php endif; ?>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-md-6">
				<div class="form-group <?php echo e($errors->has('humano') ? ' has-error ' : ''); ?>">
					<label for="humano">Coordinador Componente Humano</label>
					<input type="text" id="humano" name="humano" class="form-control" required value="<?php echo e(old('humano')); ?>" placeholder="Coordinador Academico">
					<?php if($errors->has('humano')): ?>
	          <span>
	            <strong><?php echo e($errors->first('humano')); ?></strong>
	          </span>
	      	<?php endif; ?>
				</div>
			</div>
			<div class="col-md-6">
				<div class="form-group <?php echo e($errors->has('email_h') ? ' has-error ' : ''); ?>">
					<label for="email_h">Email Coordinador Componente Humano</label>
					<input type="email" id="email_h" name="email_h" class="form-control" required value="<?php echo e(old('email_h')); ?>" placeholder="Email Coordinador Componente Humano">
					<?php if($errors->has('email_h')): ?>
	          <span>
	            <strong><?php echo e($errors->first('email_h')); ?></strong>
	          </span>
	      	<?php endif; ?>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-md-12">
				<div class="form-group <?php echo e($errors->has('acto') ? ' has-error ' : ''); ?>">
					<label for="acto">Acto Administrativo</label>
					<input type="text" id="acto" name="acto" class="form-control" required value="<?php echo e(old('acto')); ?>" placeholder="Acto Administrativo">
					<?php if($errors->has('acto')): ?>
	          <span>
	            <strong><?php echo e($errors->first('acto')); ?></strong>
	          </span>
	      	<?php endif; ?>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-md-12">
				<div class="form-group <?php echo e($errors->has('pais_id') ? ' has-error ' : ''); ?>">
					<label for="pais_id">País</label>
					<select id="pais_id" name="pais_id" class="form-control" required>
						<?php $__currentLoopData = $paises; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rowpaises): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<?php if(Auth::user()->pais_id == $rowpaises->id): ?>
								<option value="<?php echo e($rowpaises->id); ?>" selected><?php echo e(ucfirst($rowpaises->pais)); ?></option>
							<?php else: ?>
								<?php if(Auth::user()->role_id == 1): ?>
									<option value="<?php echo e($rowpaises->id); ?>"><?php echo e(ucfirst($rowpaises->pais)); ?></option>
								<?php endif; ?>
							<?php endif; ?>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
					<?php if($errors->has('pais_id')): ?>
	          <span>
	            <strong><?php echo e($errors->first('pais_id')); ?></strong>
	          </span>
	      	<?php endif; ?>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-md-12">
				<button type="submit" class="btn btn-primary">
					<i class="fa fa-floppy-o" aria-hidden="true"></i>
					Guardar
				</button>
			</div>
		</div>

	<?php echo e(Form::close()); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
	<script type="text/javascript">
	$('.tooltips').poshytip({
		className: 'tip-twitter',
		showOn: 'none',
		alignTo: 'target',
		alignX: 'inner-left',
		offsetX: 0,
		offsetY: 5
	});
        $('.tooltips').click(function(e){
        	$(this).poshytip('show');
        	$(this).poshytip('hideDelayed', 5000);
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.principal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
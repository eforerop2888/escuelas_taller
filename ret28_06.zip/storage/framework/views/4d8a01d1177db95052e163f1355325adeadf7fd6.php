<?php $__env->startSection('title', 'Ver Usuarios'); ?>
<?php $__env->startSection('subtitle', 'LISTADO DE USUARIOS'); ?>
<?php $__env->startSection('content'); ?>
	<?php if($usuarios->count()): ?>
		<table class="table table-hover">
			<tr>
				<th>#</th>
				<th>Nombre</th>
				<th>Email</th>
				<th>País</th>
				<th>Rol</th>
				<th>Ver</th>
				<?php if(Auth::user()->role_id == 1): ?>
					<th>Eliminar</th>
				<?php endif; ?>
			</tr>
			<?php ($i = 1); ?>
			<?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rowusuarios): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td><?php echo e($i); ?></td>
					<td><?php echo e(ucfirst($rowusuarios->name)); ?></td>
					<td><?php echo e($rowusuarios->email); ?></td>
					<td><?php echo e(ucfirst($rowusuarios->pais)); ?></td>
					<td><?php echo e(ucfirst($rowusuarios->role)); ?></td>
					<td>
						<?php echo e(Form::open(['method' => 'Get', 'route' => ['usuarios.show', $rowusuarios->id_users]])); ?>

							<button type="submit" class="btn btn-success">
								<i class="fa fa-eye" aria-hidden="true"></i>
							</button>
						<?php echo e(Form::close()); ?>

					</td>
					<?php if(Auth::user()->role_id == 1): ?>
						<td>
							<?php echo e(Form::open(['method' => 'Delete', 'route' => ['usuarios.destroy', $rowusuarios->id_users], 'class' => 'form-eliminar'])); ?>

								<button type="submit" class="btn btn-danger">
									<i class="fa fa-eraser" aria-hidden="true" alt="borrar"></i>
								</button>
							<?php echo e(Form::close()); ?>

						</td>
					<?php endif; ?>
				</tr>
				<?php ($i++); ?>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</table>
		<?php else: ?>
			<?php echo $__env->make('layouts.msjNoRegistros', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.principal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('title', 'Listado Escuelas'); ?>
<?php $__env->startSection('subtitle'); ?>
	LISTADO DE ESCUELAS <?php echo e(strtoupper($pais->pais)); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
	<?php if($escuelas->count()): ?>
		<div class="table-responsive">
			<table class="table table-hover">
				<tr>
					<th>#</th>
					<th>Nombre</th>
					<th>Dirección</th>
					<th>Teléfono</th>
					<th>Director</th>
					<th>País</th>
					<th>Ver</th>
					<?php if(Auth::user()->role_id == 1): ?>
						<th>Eliminar</th>
					<?php endif; ?>
				</tr>
				<?php ($i = 1); ?>
				<?php $__currentLoopData = $escuelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rowescuelas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td><?php echo e($i); ?></td>
						<td><?php echo e($rowescuelas->nombre); ?></td>
						<td><?php echo e($rowescuelas->direccion); ?></td>
						<td><?php echo e($rowescuelas->telefono); ?></td>
						<td><?php echo e($rowescuelas->director); ?></td>
						<td><?php echo e(ucfirst($rowescuelas->pais)); ?></td>
						<td>
							<?php echo e(Form::open(['method' => 'Get', 'route' => ['escuelas.show', $rowescuelas->id]])); ?>

								<button type="submit" class="btn btn-success">
									<i class="fa fa-eye" aria-hidden="true"></i>
								</button>
							<?php echo e(Form::close()); ?>

						</td>
						<?php if(Auth::user()->role_id == 1): ?>
						<td>
							<?php echo e(Form::open(['method' => 'Delete', 'route' => ['escuelas.destroy', $rowescuelas->id], 'class' => 'form-eliminar'])); ?>

								<button type="submit" class="btn btn-danger">
									<i class="fa fa-eraser" aria-hidden="true"></i>
								</button>
							<?php echo e(Form::close()); ?>

						</td>
						<?php endif; ?>
					</tr>
				<?php ($i++); ?>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</table>
		</div>
		<?php else: ?>
			<?php echo $__env->make('layouts.msjNoRegistros', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.principal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
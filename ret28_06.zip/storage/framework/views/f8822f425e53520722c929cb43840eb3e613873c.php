<?php $__env->startSection('title', 'DETALLE USUARIO'); ?>
<?php $__env->startSection('subtitle'); ?>
	Detalle usuario <?php echo e($usuario->name); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
	<div class="table-responsive">
		<table class="table table-hover">
			<tr>
				<th>Email</th>
				<td><?php echo e($usuario->email); ?></td>
			</tr>
			<tr>
				<th>País</th>
				<td><?php echo e($usuario->pais); ?></td>
			<tr/>
			<tr>
				<th>Rol</th>
				<td><?php echo e($usuario->role); ?></td>
			<tr/>
		</table>
	</div>
	<div class="row">
		<div class="col-md-12">
			<?php echo e(Form::open(['method' => 'Get', 'route' => ['usuarios.edit', $usuario->user_id]])); ?>

				<button type="submit" class="btn btn-warning">
					<i class="fa fa-edit" aria-hidden="true"></i> Editar Usuario
				</button>
			<?php echo e(Form::close()); ?>

		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.principal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('title', 'Ver Programas'); ?>
<?php $__env->startSection('subtitle'); ?>
LISTADO DE PROGRAMAS <?php echo e(strtoupper($pais->pais)); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
	<?php if($programas->count()): ?>
		<div class="table-responsive">
			<table class="table table-hover">
				<tr>
					<th>#</th>
					<th>Nombre</th>
					<th>Duración (meses)</th>
					<th>Duración en total (horas)</th>
					<th>Duración Practicas (horas)</th>
					<th>Escuela</th>
					<th>País</th>
					<th>Estado</th>
					<th>Ver</th>
					<?php if(Auth::user()->role_id == 1): ?>
						<th>Eliminar</th>
					<?php endif; ?>
				</tr>
				<?php ($i = 1); ?>
				<?php $__currentLoopData = $programas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rowprogramas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td><?php echo e($i); ?></td>
						<td><?php echo e($rowprogramas->nombre); ?></td>
						<td><?php echo e($rowprogramas->duracion_meses); ?></td>
						<td><?php echo e($rowprogramas->duracion_horas); ?></td>
						<td><?php echo e($rowprogramas->duracion_practicas_horas); ?></td>
						<td><?php echo e(ucfirst($rowprogramas->nombre_escuela)); ?></td>
						<td><?php echo e(ucfirst($rowprogramas->pais)); ?></td>
						<td><?php echo e(ucfirst($rowprogramas->estado)); ?></td>
						<td>
							<?php echo e(Form::open(['method' => 'Get', 'route' => ['programas.show', $rowprogramas->id]])); ?>

								<button type="submit" class="btn btn-success">
									<i class="fa fa-eye" aria-hidden="true"></i>
								</button>
							<?php echo e(Form::close()); ?>

						</td>
						<?php if(Auth::user()->role_id == 1): ?>
							<td>
								<?php echo e(Form::open(['method' => 'Delete', 'route' => ['programas.destroy', $rowprogramas->id], 'class' => 'form-eliminar'])); ?>

									<button type="submit" class="btn btn-danger">
										<i class="fa fa-eraser" aria-hidden="true" alt="borrar"></i>
									</button>
								<?php echo e(Form::close()); ?>

							</td>
						<?php endif; ?>
					</tr>
				<?php ($i++); ?>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</table>
		</div>
		<?php else: ?>
			<?php echo $__env->make('layouts.msjNoRegistros', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.principal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
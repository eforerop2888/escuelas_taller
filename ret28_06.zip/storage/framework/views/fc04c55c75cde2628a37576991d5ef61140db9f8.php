<?php $__env->startSection('title', 'Cargar Reprote'); ?>
<?php $__env->startSection('subtitle', 'CARGAR REPORTE'); ?>
<?php $__env->startSection('content'); ?>
	<?php echo e(Form::open(['route' => 'reportes.store', 'method' => 'POST', 'id' => 'form-crear-reporte'])); ?>

		<div class="row">
			<div class="col-md-4">
				<div class="form-group <?php echo e($errors->has('ruta') ? ' has-error ' : ''); ?>">
					<label for="ruta">Archivo</label>
					<input type="file" name="ruta" id="ruta">
					<?php if($errors->has('ruta')): ?>
			            <span>
			              <strong><?php echo e($errors->first('ruta')); ?></strong>
			            </span>
		        	<?php endif; ?>
				</div>
			</div>
			<div class="col-md-4">
				<div class="form-group <?php echo e($errors->has('nombre_archivo') ? ' has-error ' : ''); ?>">
					<label for="nombre_archivo">Nombre Reporte</label>
					<input type="text" id="nombre_archivo" name="nombre_archivo" class="form-control" value="<?php echo e(old('nombre_archivo')); ?>" required placeholder="Nombre reporte" autofocus>
					<?php if($errors->has('nombre_archivo')): ?>
            <span>
              <strong><?php echo e($errors->first('nombre_archivo')); ?></strong>
            </span>
        	<?php endif; ?>
				</div>
			</div>
			<div class="col-md-4">
				<div class="form-group <?php echo e($errors->has('estado') ? ' has-error ' : ''); ?>">
					<label for="estado">Estado</label>
					<select id="estado name="estado" class="form-control">
						<option value="0">Seleccionar</option>
						<option value="1">Publicado</option>
						<option value="2">No publicado</option>
					</select>
					<?php if($errors->has('estado')): ?>
			            <span>
			              <strong><?php echo e($errors->first('estado')); ?></strong>
			            </span>
		        	<?php endif; ?>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-md-12">
				<button type="submit" class="btn btn-primary"><i class="fa fa-floppy-o" aria-hidden="true"></i> Guardar</button>
			</div>
		</div>
	<?php echo e(Form::close()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.principal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
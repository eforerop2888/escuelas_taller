<?php $__env->startSection('title', 'Crear Programa'); ?>
<?php $__env->startSection('subtitle', 'PROGRAMAS - CREAR'); ?>
<?php $__env->startSection('content'); ?>
	<?php if($escuelas->count()): ?>
		<?php echo e(Form::open(['route' => 'programas.store', 'method' => 'POST', 'id' => 'form-crear-programa'])); ?>

			<div class="row">
				<div class="col-md-6">
					<div class="form-group <?php echo e($errors->has('nombre_programa') ? ' has-error ' : ''); ?>">
						<label for="nombre_programa">Nombre Programa</label>
						<input type="text" id="nombre_programa" name="nombre_programa" class="form-control" value="<?php echo e(old('nombre_programa')); ?>" required placeholder="Nombre Programa" autofocus>
						<?php if($errors->has('nombre_programa')): ?>
	            <span>
	              <strong><?php echo e($errors->first('nombre_programa')); ?></strong>
	            </span>
	        	<?php endif; ?>
					</div>
				</div>
				<div class="col-md-6">
					<div class="form-group <?php echo e($errors->has('duracion_meses') ? ' has-error ' : ''); ?>">
						<label for="duracion_meses">Duración meses</label>
						<input type="number" id="duracion_meses" name="duracion_meses" class="form-control" value="<?php echo e(old('duracion_meses')); ?>" required placeholder="Duración meses">
						<?php if($errors->has('duracion_meses')): ?>
				            <span>
				              <strong><?php echo e($errors->first('duracion_meses')); ?></strong>
				            </span>
			        	<?php endif; ?>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<div class="form-group <?php echo e($errors->has('duracion_horas') ? ' has-error ' : ''); ?>">
						<label for="duracion_horas">Duración en total (horas)</label>
						<input type="number" id="duracion_horas" name="duracion_horas" class="form-control" value="<?php echo e(old('duracion_horas')); ?>" required placeholder="Duración horas">
						<?php if($errors->has('duracion_horas')): ?>
				            <span>
				              <strong><?php echo e($errors->first('duracion_horas')); ?></strong>
				            </span>
			        	<?php endif; ?>
					</div>
				</div>
				<div class="col-md-6">
					<div class="form-group <?php echo e($errors->has('duracion_practica') ? ' has-error ' : ''); ?>">
						<label for="duracion_practica">Duración Practica (Horas)</label>
						<input type="number" id="duracion_practica" name="duracion_practica" class="form-control" value="<?php echo e(old('duracion_practica')); ?>" required placeholder="Duración Practica (Horas)">
						<?php if($errors->has('duracion_practica')): ?>
				            <span>
				              <strong><?php echo e($errors->first('duracion_practica')); ?></strong>
				            </span>
				        <?php endif; ?>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<div class="form-group <?php echo e($errors->has('objetivo_programa') ? ' has-error ' : ''); ?>">
						<label for="objetivo_programa">Objetivo del Programa (Máximo 500 caracteres)</label>
						<textarea id="objetivo_programa" name="objetivo_programa" class="form-control" value="<?php echo e(old('objetivo_programa')); ?>" required maxlength="500"></textarea>
						<?php if($errors->has('objetivo_programa')): ?>
				            <span>
				              <strong><?php echo e($errors->first('objetivo_programa')); ?></strong>
				            </span>
				      	<?php endif; ?>
					</div>
				</div>
				<div class="col-md-6">
					<div class="form-group <?php echo e($errors->has('requisitos_ingreso') ? ' has-error ' : ''); ?>">
						<label for="requisitos_ingreso">Requisitos de Ingreso (Máximo 500 caracteres)</label>
						<textarea id="requisitos_ingreso" name="requisitos_ingreso" class="form-control" value="<?php echo e(old('requisitos_ingreso')); ?>" required maxlength="500"></textarea>
						<?php if($errors->has('requisitos_ingreso')): ?>
				            <span>
				              <strong><?php echo e($errors->first('requisitos_ingreso')); ?></strong>
				            </span>
			        	<?php endif; ?>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<div class="form-group <?php echo e($errors->has('trabajo_egresados') ? ' has-error ' : ''); ?>">
						<label for="trabajo_egresados">Perfil de espacios laborales (Máximo 500 caracteres)</label>
						<textarea id="trabajo_egresados" name="trabajo_egresados" class="form-control" value="<?php echo e(old('trabajo_egresados')); ?>" required maxlength="500"></textarea>
						<?php if($errors->has('trabajo_egresados')): ?>
				            <span>
				              <strong><?php echo e($errors->first('trabajo_egresados')); ?></strong>
				            </span>
			        	<?php endif; ?>
					</div>
				</div>
				<div class="col-md-6">
					<div class="form-group <?php echo e($errors->has('escuelas_id') ? ' has-error ' : ''); ?>">
						<label for="escuelas_id">Seleccionar Escuela</label>
						<select id="escuelas_id" name="escuelas_id" required class="form-control">
							<?php $__currentLoopData = $escuelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rowEscuelas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<option value="<?php echo e($rowEscuelas->id); ?>"><?php echo e($rowEscuelas->nombre); ?></option>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</select>
						<?php if($errors->has('escuelas_id')): ?>
				            <span>
				              <strong><?php echo e($errors->first('escuelas_id')); ?></strong>
				            </span>
			        	<?php endif; ?>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-md-12">
					<div class="form-group <?php echo e($errors->has('estado') ? ' has-error ' : ''); ?>">
						<label for="estado">Seleccionar Estado</label>
						<select id="estado" name="estado" required class="form-control">
							<?php $__currentLoopData = $estados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rowEstados): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<option value="<?php echo e($rowEstados->id); ?>"><?php echo e(ucfirst($rowEstados->estado)); ?></option>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</select>
						<?php if($errors->has('estado')): ?>
				            <span>
				              <strong><?php echo e($errors->first('estado')); ?></strong>
				            </span>
			        	<?php endif; ?>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-md-12">
					<button type="submit" class="btn btn-primary">
						<i class="fa fa-floppy-o" aria-hidden="true"></i> 
						Guardar
					</button>
				</div>
			</div>
		<?php echo e(Form::close()); ?>

		<?php else: ?>
			<?php echo $__env->make('layouts.msjNoEscuelas', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.principal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
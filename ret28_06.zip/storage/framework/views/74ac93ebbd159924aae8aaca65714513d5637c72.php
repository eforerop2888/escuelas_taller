<?php $__env->startSection('title', 'DETALLE ESCUELA'); ?>
<?php $__env->startSection('subtitle'); ?>
	<?php echo e($escuela->nombre); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
	<div class="table-responsive">
		<table class="table table-hover">
			<tr>
				<th>País</th>
				<td colspan="2"><?php echo e(ucfirst($escuela->pais)); ?></td>
			</tr>
			<tr>
				<th>Dirección</th>
				<td colspan="2"><?php echo e($escuela->direccion); ?></td>
			</tr>
			<tr>
				<th>Teléfono</th>
				<td colspan="2"><?php echo e($escuela->telefono); ?></td>
			<tr/>
			<tr>
				<th>Página Web</th>
				<td colspan="2"><?php echo e($escuela->pagina_web); ?></td>
			<tr/>
			<tr>
				<th>Fecha Creación Escuela</th>
				<td colspan="2"><?php echo e($escuela->created_at); ?></td>
			<tr/>
			<tr>
				<th>Acto Administrativo</th>
				<td colspan="2"><?php echo e($escuela->acto_administrativo); ?></td>
			<tr/>
			<tr>
				<th>Director | Coordinador</th>
				<td><?php echo e($escuela->director); ?></td>
				<td><?php echo e($escuela->director_email); ?></td>
			</tr>
			<tr>
				<th>Coordinador Academico</th>
				<td><?php echo e($escuela->coordinador); ?></td>
				<td><?php echo e($escuela->coordinador_email); ?></td>
			</tr>		
			<tr>
				<th>Coordinador Humano</th>
				<td><?php echo e($escuela->coordinador_humano); ?></td>
				<td><?php echo e($escuela->coordinador_humano_email); ?></td>
			</tr>
		</table>
	</div>
	<div class="row">
		<div class="col-md-6 col-xs-6">
			<?php echo e(Form::open(['method' => 'Get', 'route' => ['escuelas.edit', $escuela->id]])); ?>

				<button type="submit" class="btn btn-warning">
					<i class="fa fa-edit" aria-hidden="true"></i> Editar Escuela
				</button>
			<?php echo e(Form::close()); ?>

		</div>
		<div class="col-md-6 col-xs-6">
			<?php echo e(Form::open(['method' => 'Get', 'route' => ['programas.create']])); ?>

				<input type="hidden" name="escuela" value="<?php echo e($escuela->id); ?>">
				<button type="submit" class="btn btn-primary">
					<i class="fa fa-pencil" aria-hidden="true"></i> Crear Programa
				</button>
			<?php echo e(Form::close()); ?>

		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.principal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
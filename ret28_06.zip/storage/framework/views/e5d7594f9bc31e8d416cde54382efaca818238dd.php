<?php $__env->startSection('title', 'Informes'); ?>
<?php $__env->startSection('subtitle', 'INFORMES'); ?>
<?php $__env->startSection('content'); ?>
<?php echo Charts::assets(); ?>

	<div class="panel panel-primary">
		<div class="panel-heading">
			INFORMES ESPECIFICOS
		</div>
		<div class="panel-body">
		<?php echo e(Form::open(['route' => ['informes.informeespecifico'], 'method' => 'POST', 'id' => 'form-listar-escuelas'])); ?>

			<div class="row">
				<div class="col-md-6">
					<div class="form-group">
						<label for="pais">Seleccione País</label>
						<select name="pais" id="pais" class="form-control">
							<option value="0">Seleccione</option>
							<?php $__currentLoopData = $paises; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rowpaises): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<option value="<?php echo e($rowpaises->id); ?>"><?php echo e(ucfirst($rowpaises->pais)); ?></option>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</select>
						<?php if($errors->has('pais')): ?>
				            <span>
				              <strong><?php echo e($errors->first('pais')); ?></strong>
				            </span>
		        		<?php endif; ?>
					</div>
				</div>
				<div class="col-md-6">
					<div class="form-group">
						<label for="escuela">Seleccione Escuela</label>
						<select name="escuela" id="escuela" class="form-control">
							<option value="0">Seleccione</option>
						</select>
						<?php if($errors->has('escuela')): ?>
				            <span>
				              <strong><?php echo e($errors->first('escuela')); ?></strong>
				            </span>
		        		<?php endif; ?>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-md-12">
					<div class="form-group">
						<label for="tipo_informe">Tipo de informe</label>
						<select name="tipo_informe" id="tipo_informe" class="form-control">
							<option value="0">Seleccione</option>
							<?php if(Auth::user()->role_id == 1): ?>
								<option value="1">Cooperantes</option>
								<option value="2">Cursos</option>
							<?php endif; ?>	
							<option value="3">Estudiantes</option>
							<option value="4">Programas</option>
						</select>
						<?php if($errors->has('tipo_informe')): ?>
				            <span>
				              <strong><?php echo e($errors->first('tipo_informe')); ?></strong>
				            </span>
		        		<?php endif; ?>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-md-12">
					<input type="hidden" name="token" id="token" value="<?php echo e(csrf_token()); ?>">
					<button type="submit" class="btn btn-primary">
						<i class="fa fa-file-excel-o" aria-hidden="true"></i>
						Generar Informe
					</button>
				</div>
			</div>
		<?php echo e(Form::close()); ?>

		</div>
	</div>
	<div class="panel panel-success">
		<div class="panel-heading">
			INFORME GENERAL
		</div>
		<div class="panel-body">
			<div class="table-responsive">			
				<div class="row">
					<div class="col-md-6">
				 		<?php echo $chartEscuelas->render(); ?>

				 	</div>
				 	<div class="col-md-6">
				 		<?php echo $chartProgramas->render(); ?>

				 	</div>
				</div>
				<div class="row">
					<div class="col-md-1"></div>
					<div class="col-md-10">
				 		<?php echo $chartPoblaciones->render(); ?>

				 	</div>
				 	<div class="col-md-1"></div>
				</div>
				<div class="row">
					<div class="col-md-1"></div>
				 	<div class="col-md-10">
				 		<?php echo $chartAnos->render(); ?>

				 	</div>
				 	<div class="col-md-1"></div>
				</div>
			</div>
		</div>
	</div>
	<div class="panel panel-warning">
		<div class="panel-heading">
			Gráficas especificas
		</div>
		<div class="panel-body">
			<?php echo e(Form::open(['route' => ['informes.graficoespecifico'], 'method' => 'POST', 'id' => 'form-listar-escuelas'])); ?>

				<div class="row">
					<div class="col-md-12">
						<div class="form-group">
							<label for="pais">Seleccione País</label>
							<select name="pais" id="pais" class="form-control">
								<?php $__currentLoopData = $paises; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rowpaises): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<option value="<?php echo e($rowpaises->id); ?>"><?php echo e(ucfirst($rowpaises->pais)); ?></option>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</select>
							<?php if($errors->has('pais')): ?>
					            <span>
					              <strong><?php echo e($errors->first('pais')); ?></strong>
					            </span>
			        		<?php endif; ?>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-md-12">
						<input type="hidden" name="token" id="token" value="<?php echo e(csrf_token()); ?>">
						<button type="submit" class="btn btn-primary">
							<i class="fa fa-area-chart" aria-hidden="true"></i>
							Generar Gráficas
						</button>
					</div>
				</div>
			<?php echo e(Form::close()); ?>

		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
	<script type="text/javascript">
		$('#pais').change(function(e){
			$.ajax({
	            type: "POST",
	            url: "listaescuelas",
	            data: {pais : $('#pais').val(), _token : $('#token').val()},
	            dataType: "json",
	            success: function(respuesta) {
	            	$('#escuela').empty();
	            	$('#escuela').append('<option value="0">Seleccione</option>' );
	            	var i = 0;
	            	$.each(respuesta, function( index, value ) {
					  $('#escuela').append('<option value="' + respuesta[i].id + '">'+respuesta[i].nombre+'</option>' );
					  i++;
					});
	            }
	        });
			e.preventDefault();
		});
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.secundario', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<nav class="navbar navbar-default nav_e" role="navigation">
		<div class="navbar-header">
			<a id="menu-toggle" href="#" class="navbar-toggle">
				<span class="sr-only">Toggle navigation</span>
	        <span class="icon-bar"></span>
	        <span class="icon-bar"></span>
	        <span class="icon-bar"></span>
			</a>
			<a class="navbar-brand" href="<?php echo e(route('informes')); ?>">
				<img id="logo" src="<?php echo e(URL::asset('logo.png')); ?>">
			</a>
		</div>
		<span class="user_name">
			<a href="<?php echo e(URL::asset('manual.pdf')); ?>" class="manual_uso" target="_blank">
				<i class="fa fa-question-circle" aria-hidden="true"></i>
			</a>
			<?php echo e(Auth::user()->name); ?>

		</span>
		<div id="sidebar-wrapper" class="sidebar-toggle">
			<ul class="sidebar-nav">
		    	<li>
		    		<a href="#">
		    			<i class="fa fa-building" aria-hidden="true"></i>
 						Escuelas
 					</a>
		      		<ul>
		      			<li>
		      				<a href="<?php echo e(route('escuelas.create')); ?>">
		      					<i class="fa fa-pencil" aria-hidden="true"></i>
		      					Crear
		      				</a>
		      			</li>
		      			<li>
		      				<a href="<?php echo e(route('escuelas.index')); ?>">
		      					<i class="fa fa-list-ol" aria-hidden="true"></i>
		      					Listar
		      				</a>
		      			</li>
		      		</ul>
		    	</li>
		    	<li>
	      			<a href="#">
	      				<i class="fa fa-book" aria-hidden="true"></i>
	      				Programas
	      			</a>
	      			<ul>
		      			<li>
		      				<a href="<?php echo e(route('programas.create')); ?>">
		      					<i class="fa fa-pencil" aria-hidden="true"></i>
		      					Crear
		      				</a>
		      			</li>
		      			<li>
		      				<a href="<?php echo e(route('programas.index')); ?>">
		      					<i class="fa fa-list-ol" aria-hidden="true"></i>
		      					Listar
		      				</a>
		      			</li>
		      		</ul>
		    	</li>
		    	<li>
	      			<a href="#">
	      				<i class="fa fa-handshake-o" aria-hidden="true"></i>
	      				Cooperantes
	      			</a>
	      			<ul>
		      			<li>
		      				<a href="<?php echo e(route('cooperantes.create')); ?>">
		      					<i class="fa fa-pencil" aria-hidden="true"></i>
		      					Crear
		      				</a>
		      			</li>
		      			<li>
		      				<a href="<?php echo e(route('cooperantes.index')); ?>">
		      					<i class="fa fa-list-ol" aria-hidden="true"></i>
		      					Listar
		      				</a>
		      			</li>
		      		</ul>
		    	</li>
		    	<li>
	      			<a href="#">
	      				<i class="fa fa-university" aria-hidden="true"></i>
	      				Cursos Extensión
	      			</a>
	      			<ul>
		      			<li>
		      				<a href="<?php echo e(route('cursos.create')); ?>">
		      					<i class="fa fa-pencil" aria-hidden="true"></i>
		      					Crear
		      				</a>
		      			</li>
		      			<li>
		      				<a href="<?php echo e(route('cursos.index')); ?>">
		      					<i class="fa fa-list-ol" aria-hidden="true"></i>
		      					Listar
		      				</a>
		      			</li>
		      		</ul>
		    	</li>
		    	<li>
	      			<a href="<?php echo e(route('informes')); ?>">
	      				<i class="fa fa-bar-chart" aria-hidden="true"></i>
	      				Informes
	      			</a>
		    	</li>
		    	<?php if(Auth::user()->role_id == 1): ?>
		    	<li>
	      			<a href="#">
	      				<i class="fa fa-user-circle" aria-hidden="true"></i>
	      				Usuarios
	      			</a>
	      			<ul>
		      			<li>
		      				<a href="<?php echo e(route('register')); ?>">
		      					<i class="fa fa-pencil" aria-hidden="true"></i>
		      					Crear
		      				</a>
		      			</li>
		      			<li>
		      				<a href="<?php echo e(route('usuarios.index')); ?>">
		      					<i class="fa fa-list-ol" aria-hidden="true"></i>
		      					Listar
		      				</a>
		      			</li>
		      		</ul>
		    	</li>
		    	<?php endif; ?>
		    	<li>
		    		<a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
		    			<i class="fa fa-times" aria-hidden="true"></i>
						Cerrar Sesión
		    		</a>
		    		<form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;"><?php echo e(csrf_field()); ?></form>
		    	</li>
		  	</ul>
		</div>
</nav>
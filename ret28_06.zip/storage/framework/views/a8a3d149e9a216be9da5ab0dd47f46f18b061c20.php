<?php if(Session::has('success')): ?>
	<div class="alert alert-success" role="alert">
		<strong>Perfecto</strong> <?php echo e(Session::get('success')); ?>

	</div>
<?php endif; ?>
<?php if(Session::has('fail')): ?>
	<div class="alert alert-danger" role="alert">
		<strong>Error</strong> <?php echo e(Session::get('fail')); ?>

	</div>
<?php endif; ?>